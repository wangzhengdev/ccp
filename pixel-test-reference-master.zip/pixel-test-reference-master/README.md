This repo is managed by the test/common/pixel-test tool.
